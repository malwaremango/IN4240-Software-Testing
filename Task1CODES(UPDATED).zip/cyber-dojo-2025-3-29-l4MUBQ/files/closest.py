def closest_to_zero(numbers):
    # first implementation of comparison logic
    closest = numbers[0]
    for n in numbers:
        if abs(n) < abs(closest):
            closest = n
        # tie-handler: if numbers are equally close, choose positive
        elif abs(n) == abs(closest) and n > closest:
            closest = n
    return closest