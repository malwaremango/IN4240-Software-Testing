import unittest
from closest import closest_to_zero

class TestClosestToZero(unittest.TestCase):
    def test_one_element(self):
        #for input [5], expect 5
        self.assertEqual(closest_to_zero([5]), 5)
    
    def test_two_elements(self):
        #for input [5,2], expect 2
        self.assertEqual(closest_to_zero([5,2]), 2)
        
    def test_tie_elements(self):
        #for positive and negative opposites, expect positive
        self.assertEqual(closest_to_zero([-5,5]), 5)
        
if __name__ == '__main__':
    unittest.main()